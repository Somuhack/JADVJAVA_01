package com.example.usermanagement.dto;

import lombok.Builder;
import lombok.Data;



public class UserResponseDto {
	  public UserResponseDto() {
	    }
	private Long id;
	private String name ;
	private String email;
	
	public UserResponseDto(Long id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
}
